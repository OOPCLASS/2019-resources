package com.flights.date;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateService {

	public static Date parse(Integer day, Integer month, Integer year) {
		DateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
		String dateString = String.format("%d-%d-%d", day, month, year);
		try {
			return simpleDateFormat.parse(dateString);
		} catch (ParseException e) {
			System.out.println("ParseException for " + dateString);
			return new Date();
		}
	}
}
