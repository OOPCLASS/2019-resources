package com.flights.service;

import java.util.Date;

import com.flights.model.Flight;
import com.flights.model.Passenger;

public interface FlightsService {

	boolean addPassengerToFlight(Passenger passenger, Flight flight);
	
	Flight create(Date departureDate, String fromCity, String toCity);
	
	Flight search(Date departureDate, String fromCity, String toCity);
	
	Flight[] list();
	
	Double costOfFlight(Flight flight);
}
