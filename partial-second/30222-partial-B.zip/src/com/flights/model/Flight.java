package com.flights.model;

import java.util.Date;

public abstract class Flight {

}
